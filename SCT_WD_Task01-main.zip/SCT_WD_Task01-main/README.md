# SCT_WD_Task01
Stopwatch web application for SkillCraftTechnology Task 01
